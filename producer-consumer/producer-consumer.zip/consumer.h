#ifndef CONSUMER_H
#define CONSUMER_H

void consumer_thread(int32_t tid, Queue* q);

#endif