/*
*   奇偶排序
*   1. 读取文件
*   2. 填充数组 使其大小为numprocs的整数倍
*   3. 分发数据
*   4. 本地排序
*   5. 交换排序并合并
*   6. 收集排序后数据
*/
#include <iostream>
#include <fstream>
#include <ctime>
#include <algorithm>
#include <cmath>
#include <mpi.h>
#include "utils.hpp"

#define MASTER 0
const int INF = 0x3f3f3f3f;


int main(int argc, char* argv[])
{
    int myid, numprocs, global_size, padding, local_size;
    double start, finish;
    int* unsortedArray, *sortedArray;

	sortedArray = unsortedArray = nullptr;

    MPI_Status status;
    std::ifstream inputFile;
    std::ofstream outputFile;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &myid);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
    
    if (myid == MASTER) {
        // 读取文件
        inputFile = std::ifstream("result/in.txt");
        if (!inputFile.is_open()) {
			std::cerr << "File not found." << std::endl;
            MPI_Finalize();
			std::exit(-1);
		}
        // 获取数组大小
        inputFile >> global_size;
        // 填充数组 使其大小为numprocs的整数倍
		padding = (numprocs - global_size % numprocs) % numprocs;
        unsortedArray = new int[global_size + padding];
        sortedArray = new int[global_size + padding];
        // 内存分配失败
        if (sortedArray == nullptr || sortedArray == nullptr) {
            std::cerr << "Memory allocation failed." << std::endl;
            std::exit(-1);
        }

        for (int i = 0; i < global_size; i++) {
            inputFile >> unsortedArray[i];
		}
        // 填充INF 在排序时会被排到后面
        for (int i = global_size; i < global_size + padding; ++i) {
            unsortedArray[i] = INF;
        }
        // 本地数组大小
        local_size = (global_size + padding) / numprocs;
        
        inputFile.close();
    }
    
    start = MPI_Wtime();
	MPI_Bcast(&local_size, 1, MPI_INT, MASTER, MPI_COMM_WORLD);
    MPI_Barrier(MPI_COMM_WORLD);

    // local_data 保存本地数据 partner_data 保存合作进程的数据 buffer 保存合并排序后的数据
    int* local_data = new int[local_size] {0}; 
	int* partner_data = new int[local_size] {0};
    int* buffer = new int[local_size * 2] {0};
   
    // 分发数据
    MPI_Scatter(unsortedArray, local_size, MPI_INT, local_data, local_size, MPI_INT, MASTER, MPI_COMM_WORLD);

    // 本地排序
    internal_sort(local_data, local_size);

    // 交换排序
    for (int phase = 0; phase < numprocs; ++phase) {
        int partner = ComputePartner(phase, myid, numprocs);
        if (partner == MPI_PROC_NULL) continue;
		if (myid % 2 == 0) { // 顺序相反 防止死锁
			MPI_Send(local_data, local_size, MPI_INT, partner, 0, MPI_COMM_WORLD);
			MPI_Recv(partner_data, local_size, MPI_INT, partner, 0, MPI_COMM_WORLD, &status);
			merge_and_keep(local_data, partner_data, buffer, local_size, myid < partner);
		} 
		else {
			MPI_Recv(partner_data, local_size, MPI_INT, partner, 0, MPI_COMM_WORLD, &status);
			MPI_Send(local_data, local_size, MPI_INT, partner, 0, MPI_COMM_WORLD);
			merge_and_keep(local_data, partner_data, buffer, local_size, myid < partner);
		}
    }
    // 收集排序后数据
    MPI_Gather(local_data, local_size, MPI_INT, sortedArray, local_size, MPI_INT, MASTER, MPI_COMM_WORLD);

    finish = MPI_Wtime(); 

    if (myid == MASTER) { // 将结果写入文件
        outputFile =  std::ofstream("result/out.txt");
        for (int i = 0; i < global_size; ++i) {
            outputFile << sortedArray[i] << std::endl; 
        }
        outputFile.close();
        std::cout << "调用进程数：" << numprocs << "\t"  << "消耗的时间为：" << finish - start << "s" << std::endl;
    }
    // 释放内存
    delete [] unsortedArray;
    delete [] sortedArray;
    delete [] local_data;
    delete [] partner_data;
    delete [] buffer;
    MPI_Finalize();

    return 0;

}
